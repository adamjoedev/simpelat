<h1>h1. Heading 1</h1>
<h2 class="text_shadow">h2. Heading 2</h2>
<h3 class="text_shadow">h3. Heading 3</h3>
<h4 class="text_shadow">h4. Heading 4</h4>
<h5 class="text_shadow">h5. Heading 5</h5>
<h6 class="text_shadow">h6. Heading 6</h6>
<p>This is a paragraph<br>&lt;p&gt;This is a paragraph&lt;/p&gt;</p>
<p class="dark">This is a dark paragraph<br>&lt;p class="dark"&gt;This is a dark paragraph&lt;/p&gt;</p>
<ul>
    <li>bullet points</li>
    <li>bullet points</li>
    <li>bullet points</li>
    <li>bullet points</li>
    <li>bullet points</li>
    <li>bullet points</li>
</ul>
<p>
    <input type="text" /><br>
    <input type="text" class="invalid" /><br>
    <textarea></textarea><br>
    <textarea class="invalid"></textarea><br>
    <input type="button" value="button" />
</p>