<style>
    #widget_preview_content {
        overflow: hidden;
    }
</style>
<iframe src="http://www.apple.com" width="100%" height="100%" frameborder="no"></iframe>